package com.api.runner;

import org.apache.http.util.Args;
import org.junit.runner.RunWith;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;


@RunWith(Karate.class)
@KarateOptions(
		features = "src/test/java/com/api/feature"
		)

public class CreateEmployee {

	public static void main(String[] args) {
		
		System.out.println(args[0]);
		
	}
	
}
