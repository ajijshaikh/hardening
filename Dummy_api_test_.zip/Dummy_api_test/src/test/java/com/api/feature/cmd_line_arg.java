package com.api.feature;

import org.testng.annotations.Test;

import demo.DemoTestSelected;

public class cmd_line_arg {

@Test	
public void test() {
	
	String name = System.getProperty("key");
	//System.out.println(System.getProperty("key"));
	DemoTestSelected obDemoTestSelected = new DemoTestSelected();
	String[] arrOfStr = name.split(","); 
    
	for (int i = 0; i < arrOfStr.length; i++) {
		System.out.println(arrOfStr[i]); 
    	obDemoTestSelected.testSelected(arrOfStr[i]);
	}
        
}
}
