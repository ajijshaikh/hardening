function() {    
  var env = karate.env; // get system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'dev';
  }
  var config = {
    env: env,
	myVarName: 'someValue',
	AM_HOST: 'http://dummy.restapiexample.com/api/v1',
	Feature_File_Path : "src/test/java/com/api/feature/CreateEmployeeRecord.feature"	
  }
  if (env == 'dev') {
    // customize
    // e.g. config.foo = 'bar';
  } else if (env == 'e2e') {
    // customize
  }
  return config;
}