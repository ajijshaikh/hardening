package demo.callnested;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/callnested/call-nested.feature")
public class CallNestedRunner extends TestBase {
    
}
