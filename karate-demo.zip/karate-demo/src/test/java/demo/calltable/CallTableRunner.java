package demo.calltable;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/calltable/call-table.feature")
public class CallTableRunner extends TestBase {
    
}
