package demo.greeting;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class GreetingRunner extends TestBase {
    
}
