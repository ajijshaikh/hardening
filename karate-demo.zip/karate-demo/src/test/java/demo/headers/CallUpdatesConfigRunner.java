package demo.headers;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/headers/call-updates-config.feature")
public class CallUpdatesConfigRunner extends TestBase {
    
}
