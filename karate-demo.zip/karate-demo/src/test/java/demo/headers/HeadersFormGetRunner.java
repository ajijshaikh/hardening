package demo.headers;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/headers/headers-form-get.feature")
public class HeadersFormGetRunner extends TestBase {
    
}
