package demo.jwt;

import demo.TestBase;

public class JwtRunner extends TestBase {

}
