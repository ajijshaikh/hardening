package demo.outline;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/outline/dynamic.feature")
public class DynamicRunner extends TestBase {
    
}
