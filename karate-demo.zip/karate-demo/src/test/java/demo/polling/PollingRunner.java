package demo.polling;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/polling/polling.feature")
public class PollingRunner extends TestBase {
    
}
