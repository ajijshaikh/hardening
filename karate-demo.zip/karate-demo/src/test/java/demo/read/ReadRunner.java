package demo.read;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/read/read-files.feature")
public class ReadRunner extends TestBase {
    
}
