package demo.upload;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author ssishtla
 */
@KarateOptions(features = "classpath:demo/upload/upload-multiple-fields.feature")
public class UploadMultipleFieldsRunner extends TestBase {
    
}
