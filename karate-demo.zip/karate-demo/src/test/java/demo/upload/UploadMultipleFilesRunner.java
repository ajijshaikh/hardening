package demo.upload;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author ssishtla
 */
@KarateOptions(features = "classpath:demo/upload/upload-multiple-files.feature")
public class UploadMultipleFilesRunner extends TestBase {
    
}
