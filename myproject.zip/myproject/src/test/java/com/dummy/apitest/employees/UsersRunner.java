package com.dummy.apitest.employees;

import com.intuit.karate.KarateOptions;
import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
@KarateOptions(tags = "~@ignore")
public class UsersRunner {

}